import React, { useState } from 'react';
import { CommunityPost, ModerationAnalysis } from '../types';
import { SamplePostSelector } from './SamplePostSelector';
import { AnalysisResultView } from './AnalysisResultView';
import {
  Send,
  Trash2,
  Sparkles,
  Loader2,
  FileText,
  User,
  Tag,
  ShieldCheck,
  AlertCircle
} from 'lucide-react';

interface ModerationWorkspaceProps {
  onAddPostToQueue: (post: CommunityPost) => void;
}

export const ModerationWorkspace: React.FC<ModerationWorkspaceProps> = ({
  onAddPostToQueue,
}) => {
  const [title, setTitle] = useState('');
  const [author, setAuthor] = useState('');
  const [category, setCategory] = useState<CommunityPost['category']>('Truyền thông tình nguyện');
  const [content, setContent] = useState('');
  const [selectedSampleId, setSelectedSampleId] = useState<string | undefined>();

  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [analysisResult, setAnalysisResult] = useState<ModerationAnalysis | null>(null);
  const [isAddedToQueue, setIsAddedToQueue] = useState(false);

  const handleSelectSample = (post: CommunityPost) => {
    setTitle(post.title);
    setAuthor(post.author);
    setCategory(post.category);
    setContent(post.content);
    setSelectedSampleId(post.id);
    setAnalysisResult(post.analysis || null);
    setIsAddedToQueue(false);
    setErrorMessage(null);
  };

  const handleClear = () => {
    setTitle('');
    setAuthor('');
    setContent('');
    setSelectedSampleId(undefined);
    setAnalysisResult(null);
    setIsAddedToQueue(false);
    setErrorMessage(null);
  };

  const handleAnalyze = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim()) {
      setErrorMessage('Vui lòng nhập nội dung hoặc mô tả bài viết cần kiểm duyệt.');
      return;
    }

    setIsLoading(true);
    setErrorMessage(null);
    setAnalysisResult(null);
    setIsAddedToQueue(false);

    try {
      const response = await fetch('/api/moderate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: title.trim() || 'Bài viết chưa đặt tiêu đề',
          context: category,
          text: content.trim(),
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Đã có lỗi xảy ra khi gọi dịch vụ kiểm duyệt AI.');
      }

      setAnalysisResult(data);
    } catch (err: any) {
      console.error('Moderation API call error:', err);
      setErrorMessage(
        err?.message || 'Không thể kết nối dịch vụ Gemini AI. Vui lòng thử lại sau.'
      );
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveToQueue = () => {
    if (!analysisResult) return;

    const newPost: CommunityPost = {
      id: `post-${Date.now()}`,
      title: title.trim() || 'Bài viết kiểm duyệt trực tiếp',
      author: author.trim() || 'Người dùng trực tuyến',
      category: category,
      content: content.trim(),
      createdAt: new Date().toLocaleString('vi-VN'),
      status: analysisResult.isSafe
        ? 'APPROVED'
        : analysisResult.statusText === 'Cần xem xét'
        ? 'NEEDS_REVISION'
        : 'REJECTED',
      analysis: analysisResult,
    };

    onAddPostToQueue(newPost);
    setIsAddedToQueue(true);
  };

  return (
    <div className="max-w-5xl mx-auto py-6 px-4 sm:px-6">
      
      {/* Sample Selector */}
      <SamplePostSelector
        onSelectPost={handleSelectSample}
        selectedPostId={selectedSampleId}
      />

      {/* Main Form Box */}
      <div className="bg-white rounded-2xl border border-gray-200/80 shadow-xs p-6 mb-8">
        <div className="flex items-center justify-between pb-4 mb-5 border-b border-gray-100">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 rounded-xl bg-rose-500 text-white shadow-xs">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-gray-900">
                Admin — Nhập Nội Dung Mô Tả Hoàn Cảnh Khó Khăn Cần Kiểm Duyệt
              </h2>
              <p className="text-xs text-gray-500">
                AI sẽ đánh giá tính chân thực, kiểm tra nội dung phản cảm/lừa đảo và tóm tắt 3 gạch đầu dòng
              </p>
            </div>
          </div>

          {(content || title) && (
            <button
              id="clear-form-btn"
              onClick={handleClear}
              type="button"
              className="text-xs text-gray-500 hover:text-rose-600 flex items-center gap-1 transition-colors cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Xóa nhập liệu</span>
            </button>
          )}
        </div>

        <form onSubmit={handleAnalyze} className="space-y-4">
          
          {/* Metadata inputs */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1 flex items-center gap-1">
                <FileText className="w-3.5 h-3.5 text-rose-500" />
                Tiêu đề bài viết (tùy chọn)
              </label>
              <input
                id="post-title-input"
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Ví dụ: Lịch trao quà mùa hè xanh tại Sóc Sơn..."
                className="w-full px-3.5 py-2 text-xs rounded-xl border border-gray-200 focus:border-rose-500 focus:ring-2 focus:ring-rose-200 outline-none transition-all"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1 flex items-center gap-1">
                <User className="w-3.5 h-3.5 text-rose-500" />
                Tác giả / Tổ chức gửi
              </label>
              <input
                id="post-author-input"
                type="text"
                value={author}
                onChange={(e) => setAuthor(e.target.value)}
                placeholder="Ví dụ: Đội tình nguyện Trái Tim Việt..."
                className="w-full px-3.5 py-2 text-xs rounded-xl border border-gray-200 focus:border-rose-500 focus:ring-2 focus:ring-rose-200 outline-none transition-all"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1 flex items-center gap-1">
                <Tag className="w-3.5 h-3.5 text-rose-500" />
                Thể loại nội dung
              </label>
              <select
                id="post-category-select"
                value={category}
                onChange={(e) => setCategory(e.target.value as any)}
                className="w-full px-3.5 py-2 text-xs rounded-xl border border-gray-200 bg-white focus:border-rose-500 focus:ring-2 focus:ring-rose-200 outline-none transition-all cursor-pointer"
              >
                <option value="Truyền thông tình nguyện">Truyền thông tình nguyện</option>
                <option value="Kêu gọi quyên góp">Kêu gọi quyên góp</option>
                <option value="Chia sẻ câu chuyện">Chia sẻ câu chuyện</option>
                <option value="Đóng góp ý kiến">Đóng góp ý kiến</option>
              </select>
            </div>
          </div>

          {/* Main content area */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-xs font-semibold text-gray-700 flex items-center gap-1">
                <span>Nội dung mô tả hoàn cảnh khó khăn / trường hợp cần hỗ trợ</span>
                <span className="text-red-500">*</span>
              </label>
              <span className="text-[11px] text-gray-400">
                {content.length} ký tự
              </span>
            </div>

            <textarea
              id="post-content-textarea"
              rows={6}
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Nhập hoặc dán thông tin câu chuyện, mô tả hoàn cảnh khó khăn, địa chỉ, số tài khoản kêu gọi hoặc chia sẻ cần kiểm duyệt tại đây..."
              className="w-full p-4 text-xs rounded-xl border border-gray-200 focus:border-red-500 focus:ring-2 focus:ring-red-200 outline-none transition-all leading-relaxed"
            />
          </div>

          {/* Error notice if any */}
          {errorMessage && (
            <div className="p-3 bg-red-50 border border-red-200 text-red-800 text-xs rounded-xl flex items-center space-x-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Submit Button */}
          <div className="flex justify-end pt-2">
            <button
              id="analyze-content-btn"
              type="submit"
              disabled={isLoading || !content.trim()}
              className={`inline-flex items-center gap-2 px-6 py-2.5 rounded-xl text-xs font-bold text-white transition-all shadow-md cursor-pointer ${
                isLoading || !content.trim()
                  ? 'bg-red-300 shadow-none cursor-not-allowed'
                  : 'bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-700 hover:to-rose-700 shadow-red-200 hover:shadow-lg'
              }`}
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Đang Kiểm Duyệt AI...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Kiểm duyệt tự động</span>
                </>
              )}
            </button>
          </div>

        </form>
      </div>

      {/* Result Section */}
      {analysisResult && (
        <AnalysisResultView
          analysis={analysisResult}
          onAddToQueue={handleSaveToQueue}
          onClear={handleClear}
          isAddedToQueue={isAddedToQueue}
        />
      )}

    </div>
  );
};
