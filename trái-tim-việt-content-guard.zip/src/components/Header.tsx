import React from 'react';
import { Heart, ShieldCheck, Sparkles, BookOpen } from 'lucide-react';

interface HeaderProps {
  onOpenGuidelines: () => void;
  activeTab: 'workspace' | 'queue';
  setActiveTab: (tab: 'workspace' | 'queue') => void;
  queueCount: number;
  flaggedCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenGuidelines,
  activeTab,
  setActiveTab,
  queueCount,
  flaggedCount,
}) => {
  return (
    <header className="bg-white border-b border-rose-100 sticky top-0 z-30 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          
          {/* Logo and Brand */}
          <div className="flex items-center space-x-3">
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-rose-500 to-red-600 flex items-center justify-center text-white shadow-md shadow-rose-200">
              <Heart className="w-6 h-6 fill-white stroke-none" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="text-xl font-bold text-gray-900 tracking-tight">
                  Trái Tim Việt <span className="text-red-600 font-extrabold">- AI Moderator</span>
                </h1>
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-red-50 text-red-700 border border-red-200">
                  <ShieldCheck className="w-3.5 h-3.5 text-red-600" />
                  Admin Tool
                </span>
              </div>
              <p className="text-xs text-gray-500 mt-0.5">
                Hệ thống đánh giá nội dung phản cảm & tóm tắt 3 gạch đầu dòng tự động
              </p>
            </div>
          </div>

          {/* Navigation Tabs and Actions */}
          <div className="flex items-center space-x-3">
            <div className="bg-gray-100 p-1 rounded-xl flex space-x-1 border border-gray-200/80">
              <button
                id="tab-workspace-btn"
                onClick={() => setActiveTab('workspace')}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
                  activeTab === 'workspace'
                    ? 'bg-white text-rose-700 shadow-xs'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5 text-rose-500" />
                Kiểm Duyệt Nhanh
              </button>

              <button
                id="tab-queue-btn"
                onClick={() => setActiveTab('queue')}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
                  activeTab === 'queue'
                    ? 'bg-white text-rose-700 shadow-xs'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                <span>Hàng Chờ Bài Viết</span>
                <span className="ml-1 px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800">
                  {queueCount}
                </span>
                {flaggedCount > 0 && (
                  <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
                )}
              </button>
            </div>

            <button
              id="open-guidelines-btn"
              onClick={onOpenGuidelines}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-gray-700 bg-gray-50 hover:bg-gray-100 border border-gray-200 rounded-xl transition-colors cursor-pointer"
            >
              <BookOpen className="w-3.5 h-3.5 text-rose-600" />
              <span>Tiêu Chuẩn Đăng Bài</span>
            </button>
          </div>

        </div>
      </div>
    </header>
  );
};
