import React, { useState } from 'react';
import { Header } from './components/Header';
import { ModerationWorkspace } from './components/ModerationWorkspace';
import { ReviewQueue } from './components/ReviewQueue';
import { GuidelinesModal } from './components/GuidelinesModal';
import { SAMPLE_POSTS } from './data/samplePosts';
import { CommunityPost } from './types';
import { Heart, ShieldCheck, Sparkles } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'workspace' | 'queue'>('workspace');
  const [isGuidelinesOpen, setIsGuidelinesOpen] = useState(false);
  const [queue, setQueue] = useState<CommunityPost[]>(SAMPLE_POSTS);

  const handleAddPostToQueue = (newPost: CommunityPost) => {
    setQueue((prev) => [newPost, ...prev]);
  };

  const handleUpdatePostStatus = (
    postId: string,
    status: CommunityPost['status']
  ) => {
    setQueue((prev) =>
      prev.map((p) => (p.id === postId ? { ...p, status } : p))
    );
  };

  const handleDeletePost = (postId: string) => {
    setQueue((prev) => prev.filter((p) => p.id !== postId));
  };

  const handleClearQueue = () => {
    setQueue([]);
  };

  const flaggedCount = queue.filter(
    (p) => p.status === 'REJECTED' || p.analysis?.isSafe === false
  ).length;

  return (
    <div className="min-h-screen bg-gradient-to-b from-rose-50/40 via-gray-50 to-rose-50/20 text-gray-900 flex flex-col font-sans selection:bg-rose-100 selection:text-rose-900">
      
      {/* Top Navigation Header */}
      <Header
        onOpenGuidelines={() => setIsGuidelinesOpen(true)}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        queueCount={queue.length}
        flaggedCount={flaggedCount}
      />

      {/* Main Container */}
      <main className="flex-1 py-4">
        {activeTab === 'workspace' ? (
          <ModerationWorkspace onAddPostToQueue={handleAddPostToQueue} />
        ) : (
          <ReviewQueue
            queue={queue}
            onUpdatePostStatus={handleUpdatePostStatus}
            onDeletePost={handleDeletePost}
            onClearQueue={handleClearQueue}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-rose-100 py-6 mt-12 text-center text-xs text-gray-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center space-x-2">
            <div className="w-5 h-5 rounded-full bg-rose-500 flex items-center justify-center text-white">
              <Heart className="w-3 h-3 fill-white stroke-none" />
            </div>
            <span className="font-semibold text-gray-800">Dự án Trái Tim Việt</span>
            <span>— Vì một không gian thiện nguyện minh bạch & văn minh</span>
          </div>

          <p className="text-gray-400">
            Hệ thống vận hành bởi AI Studio & Gemini 3.6 Flash Server Engine
          </p>
        </div>
      </footer>

      {/* Guidelines Modal */}
      <GuidelinesModal
        isOpen={isGuidelinesOpen}
        onClose={() => setIsGuidelinesOpen(false)}
      />

    </div>
  );
}
